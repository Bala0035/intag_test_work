import * as XLSX from 'xlsx';

export function excelRileRead(changed) {
  var selectedFile = changed.target.files[0];
  var openExcelData = new FileReader();
  openExcelData.onload = function (event) {
    var data = event.target.result;
    var workbook = XLSX.read(data, {
      type: 'binary'
    });
    workbook.SheetNames.forEach(function (sheetName) {
      var XL_row_object = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
      var json_object = JSON.stringify(XL_row_object);
      var resuld = json_object;
      console.log(resuld);
      return resuld;

    });
  };

  openExcelData.onerror = function (event) {
    console.error("File could not be read! Code " + event.target.error.code);
  };

  openExcelData.readAsBinaryString(selectedFile);
}
