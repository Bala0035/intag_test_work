import { IfcViewerAPI } from "web-ifc-viewer";import {
  MeshLambertMaterial,
} from "three";
import { jsonLoadFile } from "./ifc_to_json";
import { excelRileRead } from "./excelRileRead";


// Setup IFC
let tree;
const models = [];const subsets = {};
var contTotal; //Variable para guardar la cantidad total de línea a exportar.
const container = document.getElementById("viewer-container");
const viewer = new IfcViewerAPI({ container });
let xcalDate;
var idsets = { 1: [23613, 54451,], 2: [6876,], 3: [117147] };

const selectMat = {
  1: new
    MeshLambertMaterial({
      transparent: false,
      opacity: 1,
      color: 0x068B85,
      depthTest: true
    }),
  2: new
    MeshLambertMaterial({
      transparent: false,
      opacity: 1,
      color: 0xf1c332,
      depthTest: true
    }),

  3: new
    MeshLambertMaterial({
      transparent: false,
      opacity: 1,
      color: 0x64A5E1,
      depthTest: true
    }),
};
// Highlight items when hovering over them
// container.onmousemove = () => viewer.IFC.prePickIfcItem();

// Setup scene
viewer.addAxes();
// viewer.addGrid(100, 100);
viewer.clipper.active = true;
  
const scene = viewer.context.getScene();
viewer.IFC.applyWebIfcConfig({
  COORDINATE_TO_ORIGIN: true,
  USE_FAST_BOOLS: true
});

viewer.context.renderer.usePostproduction = true;
let numberOFLoad =1;
async function loadIFCFromURL(URL) {
   await viewer.IFC.loader.ifcManager.useWebWorkers(true, "./files/IFCWorker.js");
  const model = await viewer.IFC.loadIfcUrl(URL);
  if (model === null) return;
  models.push(model);
   console.log(numberOFLoad++);
  // model.removeFromParent();
  // await setupAllCategories();
  // tree = await viewer.IFC.getSpatialStructure(model.modelID);

  // createTreeMenu(model.modelID);
}

// Setup GUI


const GUI = {
  input: document.getElementById("file-input"),
  // exceloader: document.getElementById("ExcelLoader"),
  // excelInput: document.getElementById("excelInput"),
  loader: document.getElementById("loader-button"),
  props: document.getElementById("property-menu"),
  tree: document.getElementById("myUL"),
};

GUI.loader.onclick = () => GUI.input.click();

// GUI.exceloader.onclick = () => GUI.excelInput.click();

// GUI.excelInput.addEventListener(
//   "change", (changed) => {      
//     xcalDate= excelRileRead(changed);

//   },
//   false )
GUI.input.addEventListener(
  "change", (changed) => {
    const ifcopen = new FileReader();
    // ifcopen.onload = () => jsonLoadFile(ifcopen.result);
    ifcopen.readAsText(changed.target.files[0]);
    demoLoad(changed.target.files[0]);

  },
  false )
  function demoLoad(file) {
    const ifcURL = URL.createObjectURL(file);
    loadIFCFromURL(ifcURL)
  
  }

// Select items and log properties
window.ondblclick = async () => {
  const found = await viewer.IFC.pickIfcItem(true);
  if (found === null) return;
  const properties = await viewer.IFC.getProperties(
    found.modelID,
    found.id,
    true
  );
  createPropertiesMenu(properties);
};
window.onkeydown = (event) => {
  if (event.code === "Escape") {
    createPropertiesMenu({});
    viewer.IFC.unpickIfcItems();
  } else if (event.code === "KeyC") {
    viewer.clipper.createPlane();
  } else if (event.code === "Delete") {
    viewer.clipper.deletePlane();
    viewer.dimensions.delete();
  } else if (event.code === "KeyD") {
    viewer.dimensions.active = true;
    viewer.dimensions.previewActive = true;
    viewer.IFC.unpickIfcItems();
    viewer.IFC.unPrepickIfcItems();
    container.onmousemove = () => {};
  } else if (event.code === "KeyF") {
    viewer.dimensions.active = false;
    viewer.dimensions.previewActive = false;
    viewer.dimensions.create();
    container.onmousemove = () => viewer.IFC.prePickIfcItem();
  }
};


// Properties menu
function createPropertiesMenu(props) {
  console.log(props);
  let contId = 0; //Variable para guardar la cantidad total de línea a exportar.

  removeAllChildren(GUI.props);

  const mats = props.mats;
  const psets = props.psets;
  const type = props.type;

  delete props.mats;
  delete props.psets;
  delete props.type;

  for (let propertyName in props) {
    const propValue = props[propertyName];
    createPropertyEntry(propertyName, propValue, contId);
    contId++;
  }
  contTotal = contId;
}


function createPropertyEntry(key, propertyValue, contId) {
  // contenedor
  const root = document.createElement("div");
  root.classList.add("property-root");
  root.setAttribute("id", "root_" + contId);

  // nombre de la propiedad
  const keyElement = document.createElement("div");
  keyElement.classList.add("property-name");
  keyElement.setAttribute("id", "name_" + contId);
  keyElement.textContent = key;
  root.appendChild(keyElement);

  // valor de la propiedad
  if (propertyValue === null || propertyValue === undefined)
    propertyValue = "-";
  else if (propertyValue.value) propertyValue = propertyValue.value;

  const valueElement = document.createElement("div");
  valueElement.classList.add("property-value");
  valueElement.setAttribute("id", "value_" + contId);
  valueElement.textContent = propertyValue;
  root.appendChild(valueElement);

  GUI.props.appendChild(root);
}

function removeAllChildren(element) {
  while (element.firstChild) {
    element.removeChild(element.firstChild);
  }
}

// Tree view
var toggler = document.getElementsByClassName("caret");

for (let i = 0; i < toggler.length; i++) {
  const current = toggler[i];
  current.onclick = () => {
    current.parentElement.querySelector(".nested").classList.toggle("active");
    current.classList.toggle("caret-down");
  };
}
// Spatial tree menu
async function createTreeMenu(modelID) {
  ifcProject = await viewer.IFC.getSpatialStructure(modelID);
  removeAllChildren(GUI.tree);

  const ifcProjectNode = createNestedChild(GUI.tree, ifcProject);
  ifcProject.children.forEach((child) => {
    constructTreeMenuNode(ifcProjectNode, child);
  });
}

function constructTreeMenuNode(parent, node) {
  const children = node.children;
  if (children.length === 0) {
    createSimpleChild(parent, node);
    return;
  }
  const nodeElement = createNestedChild(parent, node);
  children.forEach((child) => {
    constructTreeMenuNode(nodeElement, child);
  });
}

function createNestedChild(parent, node) {
  const content = nodeToString(node);
  const root = document.createElement("li");
  createNestedNodeTitle(root, content);
  const childrenContainer = document.createElement("ul");
  childrenContainer.classList.add("nested");
  root.appendChild(childrenContainer);
  parent.appendChild(root);
  return childrenContainer;
}

function createNestedNodeTitle(parent, content) {
  const title = document.createElement("span");
  title.classList.add("caret");
  title.onclick = () => {
    title.parentElement.querySelector(".nested").classList.toggle("active");
    title.classList.toggle("caret-down");
  };
  title.textContent = content;
  parent.appendChild(title);
}
function createSimpleChild(parent, node) {
  const content = nodeToString(node);
  const childNode = document.createElement("li");
  childNode.classList.add("leaf-node");
  childNode.textContent = content;
  parent.appendChild(childNode);

  childNode.onmouseenter = () => {
    viewer.IFC.prepickIfcItemsByID(0, [node.expressID]);
  };

  childNode.onclick = async () => {
    viewer.IFC.pickIfcItemsByID(0, [node.expressID], true);
    const props = await viewer.IFC.getProperties(0, node.expressID, true);
    createPropertiesMenu(props);
  };
}

function nodeToString(node) {
  return `${node.type} - ${node.expressID}`;
}


// Creates a new subset containing all elements of a category
async function newSubsetOfType(i) {
  const ids = idsets[i];
  return viewer.IFC.loader.ifcManager.createSubset({
    modelID: 0,
    scene,
    ids,
    material: selectMat[i],
    removePrevious: true,
    customID: i.toString(),
  }
  );
}


async function setupAllCategories() {
  var listLength = Object.keys(idsets).length;
  for (let i = 1; i <= listLength; i++) {

    subsets[i] = await newSubsetOfType(i);
    const checkBox = document.getElementById("myIds" + i);
    checkBox.addEventListener('change', (event) => {
      const checked = event.target.checked;
      const subset = subsets[i];
      if (checked) scene.add(subset);
      else subset.removeFromParent();
    });

  }
}



