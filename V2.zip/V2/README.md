## IFC.js

This library converts any browser into an IFC viewer. It parses IFC entities to WebGL geometry through THREE.js. It is based on web-ifc-three, which is the three adaptation of web-ifc.



#### How to run locally:

run:
1- npm install
2- npm run build


